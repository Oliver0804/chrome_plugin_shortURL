# 🔍 除錯指南

## 問題：浮動氣泡沒有出現

### 快速檢查清單

#### ✅ 步驟 1：確認插件已載入
1. 前往 `chrome://extensions/`
2. 確認 "Short URL Copier" 顯示為「已啟用」
3. 檢查是否有錯誤訊息

#### ✅ 步驟 2：檢查 Content Scripts
1. 在 `chrome://extensions/` 中找到 Short URL Copier
2. 點擊「詳細資料」
3. 確認「內容腳本」區域顯示：
   - `content.js`
   - `content.css`
   - 適用於 `<all_urls>`

#### ✅ 步驟 3：重新載入插件
1. 在 `chrome://extensions/` 中
2. 點擊 Short URL Copier 的「重新載入」按鈕 (🔄)
3. 重新整理測試網頁

#### ✅ 步驟 4：檢查頁面控制台
1. 在測試網頁按 `F12` 開啟開發者工具
2. 切換到「Console」分頁
3. 查找訊息：`✓ Short URL Copier 浮動氣泡已載入`
4. 如果有錯誤訊息，記錄下來

#### ✅ 步驟 5：檢查 DOM
1. 在開發者工具的「Elements」分頁
2. 按 `Ctrl+F` (或 `Cmd+F`) 搜尋：`short-url-copier-bubble`
3. 應該能找到浮動氣泡的 div 元素

---

## 常見問題排解

### 問題 1：插件已安裝但氣泡不出現

**可能原因：**
- Content Script 未正確注入
- 頁面在插件安裝前已開啟

**解決方案：**
```bash
1. 重新整理頁面（F5）
2. 如果還是沒有，重新載入插件
3. 關閉頁面後重新開啟
```

### 問題 2：部分網站沒有氣泡

**可能原因：**
- Chrome 系統頁面不支援（chrome://, chrome-extension://）
- 某些網站的 CSP 政策阻擋

**解決方案：**
```bash
# 支援的網站：
✓ http:// 和 https:// 開頭的網站
✓ 本地 HTML 檔案（需開啟「允許存取檔案網址」）

# 不支援的網站：
✗ chrome:// 系統頁面
✗ chrome-extension:// 擴充功能頁面
✗ about:blank 空白頁
```

### 問題 3：氣泡出現但無法點擊

**可能原因：**
- z-index 被其他元素覆蓋
- CSS 樣式衝突

**解決方案：**
1. 檢查開發者工具的 Elements
2. 確認氣泡的 z-index 是否為 999999
3. 檢查是否有 `pointer-events: none` 樣式

### 問題 4：點擊氣泡沒有反應

**檢查步驟：**

1. **檢查背景腳本**
```bash
# 前往 chrome://extensions/
# 找到 Short URL Copier
# 點擊「service worker」
# 查看是否有錯誤
```

2. **檢查訊息傳遞**
```javascript
// 在頁面控制台輸入：
chrome.runtime.sendMessage(
  { action: 'cleanURL', url: window.location.href },
  (response) => console.log(response)
);
```

3. **檢查剪貼簿權限**
```bash
# 確認 manifest.json 包含：
"permissions": ["clipboardWrite"]
```

---

## 進階除錯

### 手動測試 Content Script

在頁面控制台輸入以下指令：

```javascript
// 1. 檢查氣泡是否存在
const bubble = document.getElementById('short-url-copier-bubble');
console.log('氣泡元素:', bubble);

// 2. 檢查 CSS 是否載入
const styles = Array.from(document.styleSheets).find(
  sheet => sheet.href && sheet.href.includes('content.css')
);
console.log('CSS 樣式表:', styles);

// 3. 檢查事件監聽器
if (bubble) {
  bubble.addEventListener('click', () => {
    console.log('氣泡被點擊了！');
  });
}

// 4. 測試複製功能
navigator.clipboard.writeText('測試文字').then(
  () => console.log('剪貼簿寫入成功'),
  (err) => console.error('剪貼簿寫入失敗:', err)
);
```

### 檢查 Manifest 配置

確認 `manifest.json` 的 content_scripts 設定：

```json
{
  "content_scripts": [
    {
      "matches": ["<all_urls>"],
      "js": ["content.js"],
      "css": ["content.css"],
      "run_at": "document_end"
    }
  ]
}
```

### 檢查檔案是否存在

```bash
# 在專案目錄執行
ls -la content.js content.css

# 應該看到兩個檔案
# -rw-r--r--  content.css
# -rw-r--r--  content.js
```

---

## 效能除錯

### 檢查記憶體使用

1. 開啟 Chrome 工作管理員（Shift + Esc）
2. 找到「擴充功能: Short URL Copier」
3. 查看記憶體使用（應該 < 10MB）

### 檢查 CPU 使用

1. 在工作管理員中查看 CPU 欄位
2. 正常情況應該是 0%（閒置時）
3. 點擊氣泡時可能短暫升高

---

## 測試環境建議

### 推薦測試網站

1. **本地測試頁面**
   ```bash
   # 開啟專案提供的測試頁面
   open test-bubble.html
   ```

2. **簡單網站**
   - https://example.com
   - https://www.google.com

3. **複雜網站**
   - 淘寶商品頁
   - Instagram
   - YouTube

### 不要測試的頁面

- ❌ chrome://extensions/
- ❌ chrome://settings/
- ❌ 新分頁頁面（某些版本）

---

## 重新安裝插件

如果所有方法都無效，嘗試完全重新安裝：

```bash
1. 前往 chrome://extensions/
2. 找到 Short URL Copier
3. 點擊「移除」
4. 重新載入專案資料夾
5. 測試功能
```

---

## 取得協助

### 收集除錯資訊

在回報問題前，請收集以下資訊：

1. **Chrome 版本**
   ```
   前往 chrome://settings/help
   複製版本號
   ```

2. **控制台錯誤訊息**
   ```
   開啟開發者工具 (F12)
   複製 Console 中的錯誤訊息
   ```

3. **插件狀態**
   ```
   前往 chrome://extensions/
   截圖 Short URL Copier 的狀態
   ```

4. **測試步驟**
   ```
   詳細描述：
   - 在哪個網站測試
   - 執行了什麼操作
   - 預期結果 vs 實際結果
   ```

### 建立 Issue

將收集到的資訊發送到：
- GitHub Issues
- 開發者郵箱

---

**希望這個除錯指南能幫助你解決問題！** 🔧
