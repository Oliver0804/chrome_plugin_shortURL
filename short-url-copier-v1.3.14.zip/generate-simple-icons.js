#!/usr/bin/env node

/**
 * 生成簡單的 PNG 圖示（使用 base64 編碼的最小 PNG）
 * 這是用於快速測試的臨時方案
 */

const fs = require('fs');
const path = require('path');

// 檢查 icons 目錄
const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir);
  console.log('✓ 建立 icons 目錄');
}

// 生成簡單的彩色 PNG（最小的有效 PNG 檔案）
// 這是一個 1x1 像素的紫色 PNG，可以被 Chrome 接受
function generateMinimalPNG(size, color) {
  // 使用 Canvas 或其他方法會更好，但這裡提供一個最小可用版本
  // 這是一個最小的有效 PNG header + 單色像素數據

  // 簡單的紫色漸層 PNG (使用 base64)
  const pngData = Buffer.from(
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8DwHwAFBQIAX8jx0gAAAABJRU5ErkJggg==',
    'base64'
  );

  return pngData;
}

// 生成所有尺寸的圖示
const sizes = [16, 32, 48, 128];

sizes.forEach(size => {
  const fileName = `icon${size}.png`;
  const filePath = path.join(iconsDir, fileName);

  // 生成簡單的 PNG
  const pngData = generateMinimalPNG(size, '#667eea');

  fs.writeFileSync(filePath, pngData);
  console.log(`✓ 生成 ${fileName}`);
});

console.log('\n✓ 所有圖示檔案已生成！');
console.log('\n注意：這些是臨時的最小化圖示，僅用於測試。');
console.log('建議使用以下方式生成更好的圖示：');
console.log('\n1. 在瀏覽器開啟 generate-icons.html');
console.log('2. 點擊「一鍵下載所有圖示」');
console.log('3. 將下載的檔案替換 icons 資料夾中的檔案');
console.log('\n現在可以在 Chrome 中載入插件了！');
