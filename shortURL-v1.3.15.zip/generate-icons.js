#!/usr/bin/env node

/**
 * 使用 Node.js 和 Canvas 生成插件圖示
 * 需要安裝: npm install canvas
 *
 * 如果沒有 Canvas，可以使用 generate-icons.html 在瀏覽器中生成
 */

const fs = require('fs');
const path = require('path');

// 檢查 icons 目錄是否存在
const iconsDir = path.join(__dirname, 'icons');
if (!fs.existsSync(iconsDir)) {
  fs.mkdirSync(iconsDir);
}

// 由於 Canvas 需要額外安裝，我們先創建簡單的 SVG 圖示，然後提供轉換說明
const svgIcon = `<?xml version="1.0" encoding="UTF-8"?>
<svg width="128" height="128" viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg">
  <!-- 背景漸層 -->
  <defs>
    <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#667eea;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#764ba2;stop-opacity:1" />
    </linearGradient>
  </defs>

  <!-- 圓形背景 -->
  <circle cx="64" cy="64" r="64" fill="url(#grad1)" />

  <!-- 鏈結圖示 -->
  <g stroke="#ffffff" stroke-width="8" fill="none" stroke-linecap="round">
    <!-- 左邊的鏈結 -->
    <path d="M 36 64 A 10 10 0 0 1 36 44" />
    <path d="M 36 64 A 10 10 0 0 0 36 84" />

    <!-- 右邊的鏈結 -->
    <path d="M 92 64 A 10 10 0 0 0 92 44" />
    <path d="M 92 64 A 10 10 0 0 1 92 84" />

    <!-- 中間的橫線 -->
    <line x1="46" y1="64" x2="82" y2="64" />
  </g>

  <!-- 剪刀符號 -->
  <g stroke="#ffd700" stroke-width="5" fill="none" stroke-linecap="round">
    <line x1="75" y1="25" x2="90" y2="38" />
    <line x1="90" y1="38" x2="75" y2="51" />
    <line x1="95" y1="25" x2="90" y2="38" />
    <line x1="90" y1="38" x2="95" y2="51" />
  </g>
</svg>`;

// 儲存 SVG 檔案
const svgPath = path.join(iconsDir, 'icon.svg');
fs.writeFileSync(svgPath, svgIcon);

console.log('✓ SVG 圖示已生成:', svgPath);
console.log('\n請使用以下任一方式生成 PNG 圖示：');
console.log('\n方式 1: 使用線上工具');
console.log('  1. 前往 https://cloudconvert.com/svg-to-png');
console.log('  2. 上傳 icons/icon.svg');
console.log('  3. 分別轉換為 16x16, 32x32, 48x48, 128x128');
console.log('  4. 重新命名並放入 icons 資料夾');

console.log('\n方式 2: 使用瀏覽器工具');
console.log('  1. 在瀏覽器開啟 generate-icons.html');
console.log('  2. 點擊「一鍵下載所有圖示」');
console.log('  3. 將下載的檔案放入 icons 資料夾');

console.log('\n方式 3: 使用 ImageMagick (如已安裝)');
console.log('  convert -background none icons/icon.svg -resize 16x16 icons/icon16.png');
console.log('  convert -background none icons/icon.svg -resize 32x32 icons/icon32.png');
console.log('  convert -background none icons/icon.svg -resize 48x48 icons/icon48.png');
console.log('  convert -background none icons/icon.svg -resize 128x128 icons/icon128.png');

console.log('\n方式 4: 使用簡化版 PNG (臨時測試用)');
console.log('  執行: node generate-simple-icons.js');
