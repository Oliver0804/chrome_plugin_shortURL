# 📦 安裝指南

## 快速開始

### 步驟 1：生成圖示

1. 在瀏覽器中開啟 `generate-icons.html`
   ```bash
   # 在專案目錄執行
   open generate-icons.html
   ```

2. 點擊「一鍵下載所有圖示」按鈕

3. 將下載的 4 個圖示檔案移動到 `icons` 資料夾：
   - `icon16.png`
   - `icon32.png`
   - `icon48.png`
   - `icon128.png`

### 步驟 2：載入插件到 Chrome

1. 開啟 Chrome 瀏覽器

2. 在網址列輸入：
   ```
   chrome://extensions/
   ```

3. 開啟右上角的「**開發人員模式**」開關

4. 點擊「**載入未封裝項目**」按鈕

5. 選擇本插件的資料夾（shortURL）

6. 看到插件出現在列表中，表示安裝成功！

### 步驟 3：測試功能

#### 測試一：使用測試頁面

1. 在瀏覽器中開啟 `test-urls.html`
   ```bash
   open test-urls.html
   ```

2. 檢查所有測試案例是否通過

#### 測試二：實際網站測試

1. 前往淘寶商品頁：
   ```
   https://item.taobao.com/item.htm?id=934092581657&mi_id=test&xxc=taobaoSearch
   ```

2. 點擊瀏覽器工具列的插件圖示

3. 檢查清理後的網址是否為：
   ```
   https://item.taobao.com/item.htm?id=934092581657
   ```

4. 點擊「📋 複製清理後網址」按鈕

5. 檢查剪貼簿內容是否正確

#### 測試三：Instagram 測試

1. 前往任何 Instagram 貼文或 Reel

2. 點擊插件圖示

3. 確認所有查詢參數都被移除

## 🔧 進階設定

### 自訂清理規則

編輯 `background.js` 中的 `URL_RULES` 物件：

```javascript
const URL_RULES = {
  // 新增規則：只保留特定參數
  'your-website.com': {
    keepParams: ['id', 'page', 'category']
  },

  // 或：移除特定參數
  'another-site.com': {
    removeParams: ['tracking_id', 'affiliate_code']
  }
};
```

### 修改插件外觀

編輯 `popup.css` 檔案來自訂樣式：

```css
/* 修改主題顏色 */
body {
  background: linear-gradient(135deg, #your-color-1, #your-color-2);
}

/* 修改按鈕樣式 */
.btn-primary {
  background: linear-gradient(135deg, #your-color-1, #your-color-2);
}
```

## 🐛 常見問題排解

### 問題 1：插件無法載入

**解決方案：**
- 確認 `icons` 資料夾中有所有 4 個圖示檔案
- 檢查 `manifest.json` 是否有語法錯誤
- 在 `chrome://extensions/` 頁面點擊「更新」按鈕

### 問題 2：複製功能無法使用

**解決方案：**
- 確認 Chrome 有剪貼簿權限
- 檢查瀏覽器控制台是否有錯誤訊息
- 嘗試重新載入插件

### 問題 3：某些網站無法正確清理

**解決方案：**
- 檢查 `background.js` 中是否有該網站的規則
- 可以手動添加規則（參考「自訂清理規則」）
- 提交 Issue 回報問題

## 🔄 更新插件

1. 修改程式碼後，前往 `chrome://extensions/`

2. 找到 Short URL Copier

3. 點擊重新載入圖示 (🔄)

4. 測試新功能

## 📝 開發模式除錯

### 查看控制台訊息

**背景腳本：**
1. 前往 `chrome://extensions/`
2. 找到 Short URL Copier
3. 點擊「service worker」連結
4. 開啟 DevTools

**彈出視窗：**
1. 點擊插件圖示開啟彈出視窗
2. 在彈出視窗上按右鍵 → 檢查
3. 開啟 DevTools

### 測試特定 URL

在控制台輸入：

```javascript
// 測試 URL 清理功能
const testURL = 'https://example.com/page?utm_source=test&id=123';
chrome.runtime.sendMessage(
  { action: 'cleanURL', url: testURL },
  (response) => console.log(response.cleanedURL)
);
```

## ✅ 驗證安裝

確認以下項目都正常運作：

- [ ] 插件圖示顯示在工具列
- [ ] 點擊圖示可開啟彈出視窗
- [ ] 彈出視窗正確顯示當前網址
- [ ] 清理後網址符合預期
- [ ] 複製功能正常運作
- [ ] 通知訊息正常顯示
- [ ] 所有測試案例通過

## 🎉 安裝完成！

現在你可以開始使用 Short URL Copier 了！

享受更簡潔的網址分享體驗 🚀
