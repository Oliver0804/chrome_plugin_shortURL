/**
 * 簡化版 Content Script - 用於測試
 * 只顯示一個簡單的紅色方塊來確認注入是否成功
 */

console.log('🚀 Content Script 開始執行');

// 立即執行，不等待任何條件
(function() {
  console.log('📝 當前頁面 URL:', window.location.href);
  console.log('📄 文檔狀態:', document.readyState);

  // 建立一個簡單的測試元素
  const testDiv = document.createElement('div');
  testDiv.id = 'short-url-test-element';
  testDiv.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    width: 100px;
    height: 100px;
    background: red;
    z-index: 999999;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-weight: bold;
    font-size: 14px;
    cursor: pointer;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
  `;
  testDiv.textContent = '測試';

  // 點擊事件
  testDiv.addEventListener('click', () => {
    alert('Content Script 正常運作！');
    console.log('✓ 測試元素被點擊');
  });

  // 嘗試添加到頁面
  try {
    if (document.body) {
      document.body.appendChild(testDiv);
      console.log('✓ 測試元素已添加到頁面');
      console.log('✓ 元素位置:', testDiv.getBoundingClientRect());
    } else {
      console.error('✗ document.body 不存在');
      // 等待 body 載入
      document.addEventListener('DOMContentLoaded', () => {
        if (document.body) {
          document.body.appendChild(testDiv);
          console.log('✓ 延遲添加：測試元素已添加到頁面');
        }
      });
    }
  } catch (error) {
    console.error('✗ 添加元素失敗:', error);
  }

  // 檢查現有元素
  setTimeout(() => {
    const element = document.getElementById('short-url-test-element');
    if (element) {
      console.log('✓ 確認：測試元素存在於 DOM 中');
    } else {
      console.error('✗ 測試元素未找到');
    }
  }, 1000);

})();

console.log('🏁 Content Script 執行完畢');
