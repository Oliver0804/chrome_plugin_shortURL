# 📖 使用指南

## 🫧 浮動氣泡使用方式

### 基本操作

浮動氣泡會自動出現在每個網頁的右下角，具有以下功能：

#### 1️⃣ 單擊氣泡 - 複製簡短網址
```
點擊一次 → 自動複製清理後的網址 → 顯示成功通知
```

**範例：**
- 在淘寶商品頁單擊氣泡
- 原始網址：`https://item.taobao.com/item.htm?id=123&mi_id=xxx&xxc=taobaoSearch`
- 複製結果：`https://item.taobao.com/item.htm?id=123`

#### 2️⃣ 雙擊氣泡 - 複製原始網址
```
快速雙擊 → 複製完整的原始網址
```

**適用情境：**
- 需要保留所有參數時
- 分享給技術人員除錯時

#### 3️⃣ 拖曳氣泡 - 調整位置
```
按住不放 → 移動到想要的位置 → 放開滑鼠
```

**特點：**
- 位置會記憶在該網頁
- 不會遮擋重要內容
- 可以移動到螢幕任何角落

#### 4️⃣ 鍵盤快捷鍵 - Alt + C
```
Alt + C → 立即複製簡短網址
```

**優點：**
- 無需找氣泡位置
- 雙手不離鍵盤
- 效率最高

---

## 🎨 視覺效果

### 氣泡外觀
- **顏色**：紫色漸層（#667eea → #764ba2）
- **大小**：60x60 像素（手機 50x50）
- **動畫**：輕微浮動效果
- **陰影**：柔和的紫色光暈

### 互動反饋
- **懸停時**：氣泡放大 15%
- **拖曳時**：陰影加深，放大 10%
- **複製成功**：脈衝動畫 + 頂部通知
- **工具提示**：懸停時顯示「點擊複製簡短網址」

---

## 📱 不同網站的清理規則

### 🛒 購物網站

#### 淘寶
```
清理前：
https://item.taobao.com/item.htm?id=123&mi_id=xxx&priceTId=xxx&skuId=xxx

清理後：
https://item.taobao.com/item.htm?id=123
```

### 📱 社群媒體

#### Instagram
```
清理前：
https://www.instagram.com/reel/ABC123/?utm_source=ig_web_copy_link&igsh=xxx

清理後：
https://www.instagram.com/reel/ABC123/
```

#### Facebook
```
清理前：
https://www.facebook.com/post/123?fbclid=IwAR123&ref=share

清理後：
https://www.facebook.com/post/123
```

#### Twitter/X
```
清理前：
https://twitter.com/user/status/123?s=20&t=abc123

清理後：
https://twitter.com/user/status/123
```

### 🎥 影音平台

#### YouTube
```
清理前：
https://www.youtube.com/watch?v=ABC123&feature=share&utm_source=youtube

清理後：
https://www.youtube.com/watch?v=ABC123
```

### 🌐 一般網站
```
自動移除以下追蹤參數：
- utm_source, utm_medium, utm_campaign
- fbclid, gclid, msclkid
- _ga, _gl, ref, source, share
```

---

## 💡 使用技巧

### 技巧 1：快速分享
```
1. 瀏覽到想分享的頁面
2. 按 Alt + C
3. 直接貼到聊天軟體
```

### 技巧 2：批次處理
```
1. 開啟多個分頁
2. 每個分頁按 Alt + C
3. 逐一貼到文件中
```

### 技巧 3：調整氣泡位置
```
不同網站可以設定不同位置：
- 購物網站：右下角（不擋購買按鈕）
- 文章網站：右中（方便閱讀時複製）
- 影片網站：左下角（不擋播放器）
```

### 技巧 4：檢查清理效果
```
1. 點擊工具列的插件圖示
2. 查看原始 vs 清理後的對比
3. 確認是否符合預期
```

---

## ⚠️ 注意事項

### 何時使用原始網址？
- 需要特定的追蹤代碼（如聯盟行銷）
- 分享給客服除錯時
- 保留特殊的查詢參數

### 隱私保護
- 插件不會上傳任何資料
- 所有處理都在本地完成
- 不會追蹤使用者行為

### 相容性
- ✅ 支援所有 HTTP/HTTPS 網站
- ✅ 支援動態載入的頁面
- ✅ 支援單頁應用（SPA）
- ❌ 不支援 Chrome 系統頁面（chrome://）
- ❌ 不支援瀏覽器擴充功能頁面

---

## 🔧 自訂設定

### 修改浮動氣泡樣式

編輯 `content.css` 檔案：

```css
/* 改變氣泡顏色 */
#short-url-copier-bubble {
  background: linear-gradient(135deg, #your-color-1, #your-color-2);
}

/* 改變氣泡大小 */
#short-url-copier-bubble {
  width: 70px;  /* 預設 60px */
  height: 70px;
}

/* 改變浮動動畫速度 */
@keyframes float {
  /* 調整動畫時間 */
}
```

### 新增網站清理規則

編輯 `background.js` 的 `URL_RULES`：

```javascript
const URL_RULES = {
  // 新增規則
  'your-website.com': {
    keepParams: ['id', 'page']  // 只保留這些參數
  }
};
```

---

## 🆘 常見問題

### Q1: 氣泡沒有出現？
**解答：**
1. 重新整理頁面（F5）
2. 檢查是否在支援的網站（非 chrome:// 頁面）
3. 開啟開發者工具查看錯誤訊息

### Q2: 複製失敗？
**解答：**
1. 確認瀏覽器有剪貼簿權限
2. 嘗試使用插件彈出視窗複製
3. 查看是否有其他插件衝突

### Q3: 氣泡位置跑掉？
**解答：**
1. 拖曳回想要的位置
2. 重新整理頁面會回到預設位置
3. 調整瀏覽器視窗大小後會自動調整

### Q4: 想關閉浮動氣泡？
**解答：**
目前版本無法關閉，但可以：
1. 拖曳到螢幕邊緣
2. 或編輯 `manifest.json` 移除 content_scripts

---

## 📊 效能影響

### 資源使用
- **記憶體**：< 1MB
- **CPU**：幾乎無影響
- **網路**：0（完全本地處理）

### 頁面載入
- 不影響頁面載入速度
- 在 DOM 載入完成後才注入
- 不阻擋任何網頁資源

---

**享受更簡潔的網址分享！** 🚀
